﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace WpfApp1
{

    public partial class MainWindow : Window
    {
        ObservableCollection<int> collection;
        public MainWindow()
        {
            InitializeComponent();
            collection = new();
            listBox.ItemsSource = collection;
        }

        void SayHi()
        {
            Debug.WriteLine("hello wolrld");
        }
       async void SortQuick( int left, int right)
        {
            int i = left;
            int j = right;

            int pivot = collection[Random.Shared.Next(left, right)];
            while (i <= j)
            {
                while (collection[i] < pivot) i++;
                while (collection[j] > pivot) j--;

                if (i <= j)
                {
                    int t = collection[i];
                    collection[i] = collection[j];
                    collection[j] = t;
                    i++;
                    j--;
                    await Task.Delay(100);
                }
            }
            if (i < right) SortQuick( i, right);
            if (left < j) SortQuick( left, j);
            
        }
        async void SortSelection( )
        {
            int size = collection.Count;
            for (int i = 0; i < size - 1; i++)
            {
                int pos = i;
                for (int j = i + 1; j < size; j++)
                {
                    if (collection[j] < collection[pos]) pos = j;
                }
                int temp = collection[i];
                collection[i] = collection[pos];
                collection[pos] = temp;
                await Task.Delay(100);
            }
           
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
           for (int i = 0;i<30;i++)
                collection.Add(Random.Shared.Next(400));
           
        }

        private void btnSum_Click(object sender, RoutedEventArgs e)
        {
            int a, b;
            bool f1 = int.TryParse(tbNumberA.Text, out a);
            bool f2 = int.TryParse(tbNumberB.Text, out b);
            if(f1 && f2)
            {
                lblResult.Content = $"{a} + {b} = {a+b}";
            }
            else
            {
                MessageBox.Show("eror data");
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (selectedSort.IsChecked == true) SortSelection();
            else SortQuick(0,collection.Count-1);
        }
    }
}
